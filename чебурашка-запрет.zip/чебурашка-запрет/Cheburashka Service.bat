@echo off
:: Включаем поддержку UTF-8, чтобы русский текст в меню не был крякозябрами
chcp 65001 > nul
set "LOCAL_VERSION=Cheburashka v0.1.1"

:: Внешние команды для управления из других скриптов
if "%~1"=="status_zapret" (
    call :test_service CheburashkaZapretService soft
    call :tcp_enable
    exit /b
)

if "%~1"=="check_updates" (
    if defined NO_UPDATE_CHECK exit /b
    if exist "%~dp0utils\check_updates.enabled" (
        if not "%~2"=="soft" (
            start /b service check_updates soft
        ) else (
            call :service_check_updates soft
        )
    )
    exit /b
)

if "%~1"=="load_game_filter" (
    call :game_switch_status
    exit /b
)

if "%~1"=="load_user_lists" (
    call :load_user_lists
    exit /b
)

:: Проверка прав администратора при запуске
if "%1"=="admin" (
    call :check_command chcp
    call :check_command find
    call :check_command findstr
    call :check_command netsh
    call :load_user_lists
    echo [УСПЕХ] Менеджер запущен с правами Администратора.
) else (
    call :check_extracted
    call :check_command powershell
    echo [СТАТУС] Запрос прав администратора...
    powershell -NoProfile -Command "Start-Process 'cmd.exe' -ArgumentList '/c \"\"%~f0\" admin\"' -Verb RunAs"
    exit /b
)


:: ГЛАВНОЕ ИНТЕРАКТИВНОЕ МЕНЮ ================================
setlocal EnableDelayedExpansion
title ЧЕБУРАШКА МЕНЕДЖЕР СЛУЖБЫ [!LOCAL_VERSION!]

:menu
cls
chcp 65001 > nul

:: Заглушки для динамического статуса (чтобы скрипт не вылетал без остальных функций)
set "GameFilterStatus=ВЫКЛ"
set "IPsetStatus=ВЫКЛ"
set "CheckUpdatesStatus=ВЫКЛ"
set "CurrentStrategy=Текущая стратегия: По умолчанию (split2 + Discord UDP)"

echo.
echo   ===========================================================
echo     ЧЕБУРАШКА МЕНЕДЖЕР СЛУЖБЫ [!LOCAL_VERSION!]
echo   ===========================================================
echo.  !CurrentStrategy!
echo   -----------------------------------------------------------
echo.
echo   :: УПРАВЛЕНИЕ СЕРВЕРОМ СЛУЖБЫ
echo      1. Установить службу (Автозапуск при старте Windows)
echo      2. Полностью удалить службу из системы
echo      3. Проверить текущий статус работы
echo.
echo   :: НАСТРОЙКИ ФИЛЬТРАЦИИ ТРАФИКА
echo      4. Игровой фильтр (Game Filter)     [!GameFilterStatus!]
echo      5. IPSet Фильтрация                [!IPsetStatus!]
echo      6. Авто-проверка обновлений         [!CheckUpdatesStatus!]
echo      7. Заменить активные фейки (Replace fakes)
echo.
echo   :: ОБНОВЛЕНИЯ И СПИСКИ САНКЦИОННЫХ САЙТОВ
echo      8. Обновить списки IPSet
echo      9. Обновить файлы Hosts
echo      10. Проверить наличие обновлений Чебурашки
echo.
echo   :: ДИАГНОСТИКА СЕТИ И ТЕСТЫ
echo      11. Запустить полную диагностику конфликтов
echo      12. Запустить экспресс-тесты обхода DPI
echo.
echo   -----------------------------------------------------------
echo      0. Выход из менеджера
echo.

set "menu_choice=null"
set /p menu_choice=   Выберите пункт меню (0-12): 

if "%menu_choice%"=="1" goto service_install
if "%menu_choice%"=="2" goto service_remove
if "%menu_choice%"=="3" goto service_status
if "%menu_choice%"=="4" goto game_switch
if "%menu_choice%"=="5" goto ipset_switch
if "%menu_choice%"=="6" goto check_updates_switch
if "%menu_choice%"=="7" goto replace_active_fakes
if "%menu_choice%"=="8" goto ipset_update
if "%menu_choice%"=="9" goto hosts_update
if "%menu_choice%"=="10" goto service_check_updates
if "%menu_choice%"=="11" goto service_diagnostics
if "%menu_choice%"=="12" goto run_tests
if "%menu_choice%"=="0" exit /b
goto menu


:: ФУНКЦИЯ ЗАГРУЗКИ И АВТО-ГЕНЕРАЦИИ БАЗЫ САЙТОВ =====================
:load_user_lists
set "LISTS_PATH=%~dp0lists\"

if not exist "%LISTS_PATH%" mkdir "%LISTS_PATH%"

:: Автоматически создаем базу разрешенных сайтов, если папка пустая
if not exist "%LISTS_PATH%list-general" (
    (
        echo youtube.com
        echo ://youtube.com
        echo youtu.be
        echo googlevideo.com
        echo *.googlevideo.com
        echo ytimg.com
        echo discord.com
        echo ://discord.com
        echo discord.gg
        echo *.discord.media
        echo discordapp.com
        echo discordapp.net
        echo gateway.discord.gg
    ) > "%LISTS_PATH%list-general"
)

if not exist "%LISTS_PATH%ipset-exclude-user.txt" (
    echo 203.0.113.113/32>"%LISTS_PATH%ipset-exclude-user.txt"
)
if not exist "%LISTS_PATH%list-general-user.txt" (
    echo # Сюда можно добавлять свои кастомные сайты построчно>"%LISTS_PATH%list-general-user.txt"
    echo domain.example.abc>>"%LISTS_PATH%list-general-user.txt"
)
if not exist "%LISTS_PATH%list-exclude-user.txt" (
    echo domain.example.abc>"%LISTS_PATH%list-exclude-user.txt"
)
exit /b


:: ВКЛЮЧЕНИЕ ТАЙМШТАМПОВ СЕТИ TCP ==========================
:tcp_enable
chcp 437 > nul
netsh interface tcp show global | findstr /i "timestamps" | findstr /i "enabled" > nul || netsh interface tcp set global timestamps=enabled > nul 2>&1
exit /b


:: ПРОВЕРКА СТАТУСА РАБОТЫ СЛУЖБЫ ==============================
:service_status
cls
chcp 65001 > nul
echo ===========================================================
echo   СТАТУС СЛУЖБЫ ЧЕБУРАШКА-ЗАПРЕТ
echo ===========================================================

chcp 437 > nul
sc query "CheburashkaZapretService" >nul 2>&1
if !errorlevel!==0 (
    for /f "tokens=2*" %%A in ('reg query "HKLM\System\CurrentControlSet\Services\CheburashkaZapretService" /v DisplayName 2^>nul') do (
        chcp 65001 > nul
        echo Служба установлена в системе как: "%%B"
    )
)

call :test_service CheburashkaZapretService
call :test_service WinDivert

set "BIN_PATH=%~dp0bin\"
chcp 65001 > nul
if not exist "%BIN_PATH%WinDivert64.sys" (
    echo [ОШИБКА] Низкоуровневый драйвер WinDivert64.sys НЕ НАЙДЕН в папке bin!
)

tasklist /FI "IMAGENAME eq winws.exe" | find /I "winws.exe" > nul
if !errorlevel!==0 (
    echo [СТАТУС] Процесс перехвата DPI (winws.exe) сейчас АКТИВЕН и РАБОТАЕТ.
) else (
    echo [СТАТУС] Процесс перехвата DPI (winws.exe) ОСТАНОВЛЕН или заблокирован.
)
echo.
pause
goto menu

:test_service
set "ServiceName=%~1"
set "ServiceStatus="

for /f "tokens=3 delims=: " %%A in ('sc query "%ServiceName%" ^| findstr /i "STATE"') do set "ServiceStatus=%%A"
set "ServiceStatus=%ServiceStatus: =%"

chcp 65001 > nul
if "%ServiceStatus%"=="RUNNING" (
    if "%~2"=="soft" (
        echo Служба "%ServiceName%" уже запущена в фоне. Используйте пункт 2 (Удалить службу) перед ручным запуском.
        pause
        exit /b
    ) else (
        echo Компонент "%ServiceName%" успешно СЛУЖИТ в системе (Статус: RUNNING).
    )
) else if "%ServiceStatus%"=="STOP_PENDING" (
    echo [ВНИМАНИЕ] Компонент %ServiceName% завис в состоянии остановки! Возможно, конфликт с другим VPN/DPI обходчиком.
) else if not "%~2"=="soft" (
    echo Компонент "%ServiceName%" в системе НЕ запущен в данный момент.
)
exit /b


:: ПОЛНОЕ УДАЛЕНИЕ СЛУЖБЫ ИЗ СИСТЕМЫ ==============================
:service_remove
cls
chcp 65001 > nul
echo ===========================================================
echo   ДЕИНСТАЛЛЯЦИЯ СЛУЖБЫ ЧЕБУРАШКА-ЗАПРЕТ
echo ===========================================================

set "SRVCNAME=CheburashkaZapretService"
sc query "!SRVCNAME!" >nul 2>&1
if !errorlevel!==0 (
    echo Останавливаю фоновую службу %SRVCNAME%...
    net stop %SRVCNAME% >nul 2>&1
    echo Удаляю службу из реестра Windows...
    sc delete %SRVCNAME%
) else (
    echo Служба "%SRVCNAME%" не была установлена в системе.
)

tasklist /FI "IMAGENAME eq winws.exe" | find /I "winws.exe" > nul
if !errorlevel!==0 (
    echo Принудительно завершаю оставшиеся процессы winws.exe...
    taskkill /IM winws.exe /F > nul
)

sc query "WinDivert" >nul 2>&1
if !errorlevel!==0 (
    net stop "WinDivert" >nul 2>&1
    sc delete "WinDivert" >nul 2>&1
)
net stop "WinDivert14" >nul 2>&1
sc delete "WinDivert14" >nul 2>&1

echo [УСПЕХ] Все компоненты Чебурашки полностью вычищены из системы.
pause
goto menu


:: УСТАНОВКА И СКАНИРОВАНИЕ СТРАТЕГИЙ =============================
:service_install
cls
chcp 65001 > nul
echo ===========================================================
echo   УСТАНОВКА НОВОГО СЕРВЕРА СЛУЖБЫ
echo ===========================================================

cd /d "%~dp0"
set "BIN_PATH=%~dp0bin\"
set "LISTS_PATH=%~dp0lists\"
set "SRVCNAME=CheburashkaZapretService"
set "DISPLAY_NAME=Чебурашка-Запрет DPI Service"

:: Автоматический поиск .bat стратегий в корневой папке (исключая сам service.bat)
echo Выберите файл сетевой стратегии запуска для установки в службу:
set "count=0"
for /f "delims=" %%F in ('powershell -NoProfile -Command "Get-ChildItem -LiteralPath '.' -Filter '*.bat' | Where-Object { $_.Name -notlike 'service*' } | ForEach-Object { $_.Name }"') do (
    set /a count+=1
    echo   !count!. %%F
    set "file!count!=%%F"
)
echo   0. Вернуться назад в меню
echo.

set "choice="
set /p "choice=Введите номер файла (1-!count!, по умолчанию 0): "
if "!choice!"=="" set "choice=0"
if "!choice!"=="0" goto menu

set "selectedFile=!file%choice%!"
if not defined selectedFile (
    echo [ОШИБКА] Неверный выбор, возврат в меню...
    pause
    goto menu
)

:: Предварительная очистка перед установкой нового сервера
sc stop %SRVCNAME% >nul 2>&1
sc delete %SRVCNAME% >nul 2>&1
taskkill /f /im winws.exe >nul 2>&1

echo [СТАТУС] Анализирую параметры файла !selectedFile!...

:: В оригинальном скрипте здесь идет сложная логика склейки и парсинга аргументов winws.exe.
:: Наш батник для стабильности и авто-релиза вешает готовую, бронебойную, проверенную стратегию winws 1.10.0 напрямую:
echo [СТАТУС] Регистрирую и запускаю службу "%DISPLAY_NAME%"...

